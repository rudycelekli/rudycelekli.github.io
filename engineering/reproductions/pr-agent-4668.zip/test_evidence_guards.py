import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent

class EvidenceGuards(unittest.TestCase):
    def copied(self, temp):
        target = Path(temp)
        shutil.copyfile(ROOT/'manifest.json', target/'manifest.json')
        shutil.copytree(ROOT/'sources', target/'sources')
        shutil.copytree(ROOT/'dependency', target/'dependency')
        return target

    def invoke(self, root):
        return subprocess.run([sys.executable, str(ROOT/'run_reconstruction.py'), '--root', str(root)], capture_output=True, text=True)

    def test_complete_replay_and_both_mutants(self):
        with tempfile.TemporaryDirectory() as temp:
            root = self.copied(temp)
            result = self.invoke(root)
            self.assertEqual(result.returncode, 0, result.stderr)
            receipt = json.loads((root/'reproduction-receipt.json').read_text())
            self.assertEqual(receipt['cases_per_variant'], 11)
            self.assertEqual(receipt['failures']['candidate'], [])
            self.assertEqual(len(receipt['failures']['baseline']), 9)
            self.assertIn('unicode_line', receipt['failures']['old_splitlines_mutant'])
            self.assertEqual(receipt['failures']['old_rstrip_mutant'], ['repeated_carriage_returns'])

    def test_changed_source_fails_before_receipt(self):
        with tempfile.TemporaryDirectory() as temp:
            root = self.copied(temp)
            file = root/'sources/candidate/pr_agent/git_providers/diff_parsing.py'
            file.write_bytes(file.read_bytes()+b'\n# corrupted source\n')
            result = self.invoke(root)
            self.assertEqual(result.returncode, 2)
            self.assertIn('hash mismatch', result.stderr)
            self.assertFalse((root/'reproduction-receipt.json').exists())

    def test_changed_manifest_commit_label_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = self.copied(temp)
            file = root/'manifest.json';data=json.loads(file.read_text());data['candidate']='0'*40;file.write_text(json.dumps(data))
            result = self.invoke(root)
            self.assertEqual(result.returncode, 2)
            self.assertIn('hash mismatch', result.stderr)
            self.assertFalse((root/'reproduction-receipt.json').exists())

    def test_changed_dependency_wheel_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = self.copied(temp)
            file = next((root/'dependency').glob('*.whl'));file.write_bytes(file.read_bytes()+b'corrupt')
            result = self.invoke(root)
            self.assertEqual(result.returncode, 2)
            self.assertIn('hash mismatch', result.stderr)
            self.assertFalse((root/'reproduction-receipt.json').exists())

    def test_optimized_python_rejects_a_deliberately_wrong_oracle(self):
        with tempfile.TemporaryDirectory() as temp:
            root = self.copied(temp)
            code = "import sys; import run_reconstruction as r; original=r.cases; r.cases=lambda: [dict(row, expected='deliberately incorrect oracle') for row in original()]; sys.argv=['run_reconstruction.py','--root',sys.argv[1]]; r.main()"
            result = subprocess.run([sys.executable, '-O', '-c', code, str(root)], cwd=ROOT, capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('Candidate did not match ground truth', result.stderr)
            self.assertFalse((root/'reproduction-receipt.json').exists())

if __name__ == '__main__':
    unittest.main()
