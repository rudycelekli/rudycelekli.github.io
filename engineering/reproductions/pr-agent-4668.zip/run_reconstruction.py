#!/usr/bin/env python3
"""Isolated, source-bound replay of PR-Agent #4668 reverse reconstruction.

This extracts three unmodified function ASTs, not the full provider/application.
Only the pinned unidiff dependency and a logging-only adapter are injected.
"""
import argparse
from datetime import datetime, timezone
import ast
import hashlib
import importlib.metadata
import io
import json
import logging
import platform
import sys
import zipfile
from pathlib import Path
from urllib.request import urlopen


EXPECTED_MANIFEST_SHA256 = '69b4b0706a8d1e8bb31bc6205dea68f840aecf5151604e6a5f327db22ee2e6f0'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def checked_bytes(path, expected):
    raw = path.read_bytes()
    if digest(raw) != expected:
        raise ValueError(f"Source/dependency hash mismatch: {path.name}")
    return raw


def prepare(root, manifest, fetch):
    # Check every recorded source before importing or executing extracted code.
    for record in manifest['files']:
        path = root / record['path']
        if not path.exists() and fetch:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(urlopen(record['url'], timeout=30).read())
        checked_bytes(path, record['sha256'])
    dep = manifest['dependency']
    wheel = root / 'dependency' / dep['filename']
    if not wheel.exists() and fetch:
        wheel.parent.mkdir(parents=True, exist_ok=True)
        wheel.write_bytes(urlopen(dep['url'], timeout=30).read())
    raw = checked_bytes(wheel, dep['sha256'])
    # Import directly from the hash-verified wheel; do not modify global packages.
    sys.path.insert(0, str(wheel))
    import unidiff
    from unidiff.errors import UnidiffParseError
    if not str(unidiff.__file__).startswith(str(wheel) + '/'):
        raise ValueError('unidiff was not imported from the hash-verified wheel')
    if importlib.metadata.version('unidiff') != dep['version']:
        raise ValueError('Imported unidiff version differs from recorded upstream pin')
    return unidiff.PatchSet, UnidiffParseError


def function_node(path, name):
    tree = ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
    found = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name]
    if len(found) != 1:
        raise ValueError(f'Expected exactly one function named {name}')
    return found[0]


def load(root, label, patch_set, parse_error, mutation=None):
    path = root / 'sources' / label
    parser = path / 'pr_agent/git_providers/diff_parsing.py'
    splitter = path / 'pr_agent/algo/git_patch_processing.py'
    nodes = [function_node(splitter, 'split_diff_lines'),
             function_node(parser, 'reconstruct_base_file_checked'),
             function_node(parser, 'reconstruct_base_file')]
    if mutation:
        class Reintroduce(ast.NodeTransformer):
            count = 0
            def visit_Call(self, node):
                node = self.generic_visit(node)
                if mutation == 'old_splitlines' and isinstance(node.func, ast.Name) and node.func.id == 'split_diff_lines':
                    self.count += 1
                    return ast.copy_location(ast.Call(func=ast.Attribute(value=ast.Name(id='head_file_str', ctx=ast.Load()), attr='splitlines', ctx=ast.Load()), args=[], keywords=[]), node)
                if mutation == 'old_rstrip' and isinstance(node.func, ast.Attribute) and node.func.attr == 'removesuffix' and isinstance(node.func.value, ast.Call) and isinstance(node.func.value.func, ast.Attribute) and node.func.value.func.attr == 'removesuffix':
                    self.count += 1
                    return ast.copy_location(ast.Call(func=ast.Attribute(value=ast.Attribute(value=ast.Name(id='line', ctx=ast.Load()),attr='value',ctx=ast.Load()),attr='rstrip',ctx=ast.Load()),args=[ast.Constant(value='\r\n')],keywords=[]), node)
                return node
        transformer = Reintroduce()
        nodes[1] = transformer.visit(nodes[1])
        if transformer.count != 1:
            raise ValueError('Mutation did not affect exactly the intended expression')
    module = ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[]))
    namespace = {'PatchSet': patch_set, 'UnidiffParseError': parse_error,
                 'get_logger': lambda: logging.getLogger('isolated-reconstruction')}
    exec(compile(module, str(parser), 'exec'), namespace)
    return namespace['reconstruct_base_file_checked']


def cases():
    rows = []
    # Expected complete base content is independently specified, never computed by
    # the implementation under test, str.splitlines(), or reverse-patch helpers.
    for name, sep in [('unicode_line', '\u2028'), ('unicode_paragraph', '\u2029'),
                      ('nel', '\x85'), ('form_feed', '\f'), ('vertical_tab', '\v'),
                      ('file_separator', '\x1c'), ('carriage_return', '\r')]:
        rows.append({'id': name, 'head': f'first{sep}continued\nnew\nlast\n',
          'patch': f'--- a/f.txt\n+++ b/f.txt\n@@ -1,3 +1,3 @@\n first{sep}continued\n-old\n+new\n last\n',
          'expected': f'first{sep}continued\nold\nlast\n'})
    rows += [
      {'id':'separator_before_later_hunk', 'head':'first\u2028continued\nunchanged\nnew\n',
       'patch':'--- a/f.txt\n+++ b/f.txt\n@@ -3 +3 @@\n-old\n+new\n',
       'expected':'first\u2028continued\nunchanged\nold\n'},
      {'id':'repeated_carriage_returns', 'head':'first\r\r\nnew\n',
       'patch':'--- a/f.txt\n+++ b/f.txt\n@@ -1,2 +1,2 @@\n first\r\r\n-old\n+new\n',
       'expected':'first\r\nold\n'},
      {'id':'ordinary_lf_control', 'head':'first\nnew\nlast\n',
       'patch':'--- a/f.txt\n+++ b/f.txt\n@@ -1,3 +1,3 @@\n first\n-old\n+new\n last\n',
       'expected':'first\nold\nlast\n'},
      {'id':'mismatched_head_rejected', 'head':'first\nDIFFERENT\nlast\n',
       'patch':'--- a/f.txt\n+++ b/f.txt\n@@ -1,3 +1,3 @@\n first\n-old\n+new\n last\n',
       'expected':None},
    ]
    return rows


def evaluate(fn, rows):
    results = []
    for row in rows:
        result = fn(row['head'], row['patch'])
        results.append({'case':row['id'], 'expected':row['expected'], 'actual':result,
                        'matches_ground_truth':result == row['expected']})
    return results


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    ap.add_argument('--fetch', action='store_true', help='Fetch missing immutable sources and pinned wheel; never repair mismatched bytes')
    ap.add_argument('--receipt', default='reproduction-receipt.json')
    args = ap.parse_args()
    if sys.version_info < (3, 10):
        raise ValueError('Python 3.10 or later is required by the upstream function annotations')
    manifest = json.loads(checked_bytes(args.root/'manifest.json', EXPECTED_MANIFEST_SHA256))
    patch_set, parse_error = prepare(args.root, manifest, args.fetch)
    rows = cases()
    outcomes = {label:evaluate(load(args.root,label,patch_set,parse_error),rows) for label in ['baseline','candidate']}
    outcomes['old_splitlines_mutant'] = evaluate(load(args.root,'candidate',patch_set,parse_error,'old_splitlines'),rows)
    outcomes['old_rstrip_mutant'] = evaluate(load(args.root,'candidate',patch_set,parse_error,'old_rstrip'),rows)
    failures = {label:[r['case'] for r in result if not r['matches_ground_truth']] for label,result in outcomes.items()}
    if failures['candidate']:
        raise ValueError(f"Candidate did not match ground truth: {failures['candidate']}")
    if not failures['baseline']:
        raise ValueError('Baseline did not reproduce the defect')
    for control in ['ordinary_lf_control','mismatched_head_rejected']:
        if control in failures['baseline']:
            raise ValueError('Baseline control failed')
    if 'unicode_line' not in failures['old_splitlines_mutant']:
        raise ValueError('Splitlines mutant escaped the evaluator')
    if 'repeated_carriage_returns' not in failures['old_rstrip_mutant']:
        raise ValueError('Rstrip mutant escaped the evaluator')
    receipt = {'schema':'pr-agent-4668.isolated-reconstruction.v1',
      'captured_at_utc':datetime.now(timezone.utc).isoformat(),
      'source_files':manifest['files'],
      'python':platform.python_version(), 'baseline':manifest['baseline'], 'candidate':manifest['candidate'],
      'manifest_sha256':digest((args.root/'manifest.json').read_bytes()),
      'runner_sha256':digest(Path(__file__).read_bytes()), 'unidiff':manifest['dependency'],
      'cases_per_variant':len(rows), 'failures':failures, 'results':outcomes,
      'scope':'Fresh isolated function replay, not full upstream module/provider integration or historical suite rerun',
      'injected_dependencies':['Pinned unidiff PatchSet and UnidiffParseError', 'stdlib logging adapter through get_logger'],
      'loaded_definitions':['split_diff_lines', 'reconstruct_base_file_checked', 'reconstruct_base_file'],
      'exercised_entrypoint':'reconstruct_base_file_checked',
      'candidate_exercised_helpers':['split_diff_lines'],
      'compiled_only_definitions':['reconstruct_base_file'],
      'mutants':'Separately labeled mutants intentionally alter one expression each; ordinary candidate AST definitions are unmodified',
      'limits':['Known regression cases derived from the public fix, not a protected holdout.', 'Does not exercise MOSAICO supplied-diff parsing, complete package imports, provider APIs, application configuration, released package bytes, customer acceptance, or unassisted authorship.'],
      'status':'BASELINE_REPRODUCED_CANDIDATE_PASS_MUTANTS_REJECTED'}
    (args.root/args.receipt).write_text(json.dumps(receipt,indent=2,ensure_ascii=True)+'\n')
    print(json.dumps({'status':receipt['status'],'cases_per_variant':len(rows),'failures':failures},indent=2))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError) as exc:
        print(f'FAIL CLOSED: {exc}', file=sys.stderr)
        sys.exit(2)
