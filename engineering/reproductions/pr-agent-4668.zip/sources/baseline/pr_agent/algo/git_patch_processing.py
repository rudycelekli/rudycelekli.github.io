from __future__ import annotations

import re
import traceback
from codecs import BOM_UTF16_BE, BOM_UTF16_LE

from pr_agent.algo.setting_utils import normalize_setting_list
from pr_agent.algo.types import EDIT_TYPE
from pr_agent.config_loader import get_settings, get_verbosity_level
from pr_agent.log import get_logger

# Optimized: Pre-compile the hunk header regex at the module level to avoid redundant compilation
# in performance-critical patch processing functions.
RE_HUNK_HEADER = re.compile(
    r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@[ ]?(.*)")
NO_NEWLINE_AT_EOF_MARKER = r'\ No newline at end of file'
_SPLITLINES_BREAK_CHARS = "\n\r\v\f\x1c\x1d\x1e\x85\u2028\u2029"


def split_diff_lines(text: str) -> list[str]:
    """Split on line feeds only, as git does; ``str.splitlines()`` also breaks on U+2028, form feeds, etc."""
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    return [line.removesuffix("\r") for line in lines]


def count_patch_lines(patch: str) -> tuple[int, int]:
    """Count added and removed lines using Git's LF-delimited patch lines."""
    return patch.count("\n+") + patch.startswith("+"), patch.count("\n-") + patch.startswith("-")


def to_hunk_only_patch(patch_str: str) -> str:
    """Drop unified-diff file metadata before the first hunk.

    ``FilePatchInfo.patch`` consumers expect hunk-only patches and may otherwise
    treat ``---``/``+++`` file headers as changed source lines. Returns an empty
    string when the diff has no textual hunk, for example a rename-only change.
    """
    hunk_start = patch_str.find("@@")
    while hunk_start != -1:
        if hunk_start == 0 or patch_str[hunk_start - 1] in _SPLITLINES_BREAK_CHARS:
            return patch_str[hunk_start:]
        hunk_start = patch_str.find("@@", hunk_start + 2)
    return ""


def extend_patch(original_file_str, patch_str, patch_extra_lines_before=0,
                 patch_extra_lines_after=0, filename: str = "", new_file_str="") -> str:
    if not patch_str or (patch_extra_lines_before == 0 and patch_extra_lines_after == 0) or not original_file_str:
        return patch_str

    original_file_str = decode_if_bytes(original_file_str)
    new_file_str = decode_if_bytes(new_file_str)
    if not original_file_str:
        return patch_str

    if should_skip_patch(filename):
        return patch_str

    try:
        extended_patch_str = process_patch_lines(patch_str, original_file_str,
                                                 patch_extra_lines_before, patch_extra_lines_after, new_file_str)
    except Exception as e:
        get_logger().warning(f"Failed to extend patch: {e}", artifact={"traceback": traceback.format_exc()})
        return patch_str

    return extended_patch_str


def decode_if_bytes(original_file_str):
    if isinstance(original_file_str, (bytes, bytearray)):
        if original_file_str.startswith((BOM_UTF16_LE, BOM_UTF16_BE)):
            try:
                return original_file_str.decode('utf-16')
            except UnicodeDecodeError:
                pass
        try:
            return original_file_str.decode('utf-8')
        except UnicodeDecodeError:
            return original_file_str.decode('latin-1')
    return original_file_str


def should_skip_patch(filename):
    patch_extension_skip_types = normalize_setting_list(get_settings().config.patch_extension_skip_types)
    if patch_extension_skip_types and filename:
        return any(filename.lower().endswith(str(skip_type).lower()) for skip_type in patch_extension_skip_types)
    return False


def process_patch_lines(patch_str, original_file_str, patch_extra_lines_before, patch_extra_lines_after,
                        new_file_str=""):
    allow_dynamic_context = get_settings().config.allow_dynamic_context
    patch_extra_lines_before_dynamic = get_settings().config.max_extra_lines_before_dynamic_context

    file_original_lines = split_diff_lines(original_file_str)
    len_original_lines = len(file_original_lines)
    patch_lines = split_diff_lines(patch_str)
    # Head lines are only consulted before each hunk, never after it.
    # Zero-length head hunks point to the line preceding an insertion/deletion.
    head_prefix_lines = max((
        max(0, int(match.group(3)) - 1 + (match.group(4) == "0"))
        for line in patch_lines if (match := RE_HUNK_HEADER.match(line))
    ), default=0)
    file_new_lines = []
    if new_file_str and head_prefix_lines:
        end = 0
        for _ in range(head_prefix_lines):
            next_end = new_file_str.find('\n', end)
            if next_end < 0:
                end = len(new_file_str)
                break
            end = next_end + 1
        file_new_lines = split_diff_lines(new_file_str[:end])
    extended_patch_lines = []
    hunk_starts = [(i, int(match.group(1))) for i, line in enumerate(patch_lines)
                   if (match := RE_HUNK_HEADER.match(line))]
    next_hunk_start = {
        current[0]: following[1] for current, following in zip(hunk_starts, hunk_starts[1:], strict=False)
    }

    is_valid_hunk = True
    start1, size1, start2, size2 = -1, -1, -1, -1
    extra_lines_after = 0
    last_extended_old_line = 0
    try:
        for i,line in enumerate(patch_lines):
            if line.startswith('@@'):
                match = RE_HUNK_HEADER.match(line)
                # identify hunk header
                if match:
                    # finish processing previous hunk
                    if is_valid_hunk and (start1 != -1 and extra_lines_after > 0):
                        delta_lines_original = [
                            f' {line}'
                            for line in file_original_lines[
                                start1 + size1 - 1:start1 + size1 - 1 + extra_lines_after
                            ]
                        ]
                        extended_patch_lines.extend(delta_lines_original)

                    section_header, size1, size2, start1, start2 = extract_hunk_headers(match)
                    # Shift a zero-length side (a pure insertion or deletion, as in `git diff -U0`) by one line:
                    # its header numbers the line *before* the change.
                    header_start1, header_start2 = start1, start2
                    if size1 == 0:
                        start1 += 1
                    if size2 == 0:
                        start2 += 1

                    extra_lines_after = min(
                        patch_extra_lines_after,
                        max(0, next_hunk_start.get(i, len_original_lines + 1) - start1 - size1),
                    )

                    is_valid_hunk = check_if_hunk_lines_matches_to_file(i, file_original_lines, patch_lines, start1)

                    if is_valid_hunk and (patch_extra_lines_before > 0 or patch_extra_lines_after > 0):
                        def _calc_context_limits(
                            patch_lines_before,
                            start1=start1,
                            size1=size1,
                            start2=start2,
                            size2=size2,
                            extra_lines_after=extra_lines_after,
                            last_extended_old_line=last_extended_old_line,
                        ):
                            lines_before = min(patch_lines_before, start1 - 1, start2 - 1,
                                               start1 - last_extended_old_line - 1)
                            lines_before = max(0, lines_before)
                            extended_start1 = start1 - lines_before
                            extended_size1 = size1 + lines_before + extra_lines_after
                            extended_start2 = start2 - lines_before
                            extended_size2 = size2 + lines_before + extra_lines_after
                            if extended_start1 - 1 + extended_size1 > len_original_lines:
                                # we cannot extend beyond the original file
                                delta_cap = extended_start1 - 1 + extended_size1 - len_original_lines
                                extended_size1 = max(extended_size1 - delta_cap, size1)
                                extended_size2 = max(extended_size2 - delta_cap, size2)
                            return extended_start1, extended_size1, extended_start2, extended_size2

                        if allow_dynamic_context and file_new_lines and section_header.strip():
                            extended_start1, extended_size1, extended_start2, extended_size2 = \
                                _calc_context_limits(patch_extra_lines_before_dynamic)

                            lines_before_original = file_original_lines[extended_start1 - 1:start1 - 1]
                            lines_before_new = file_new_lines[extended_start2 - 1:start2 - 1]
                            found_header = False
                            for i, line in enumerate(lines_before_original):
                                if section_header in line:
                                    # Update start and size in one line each
                                    extended_start1, extended_start2 = extended_start1 + i, extended_start2 + i
                                    extended_size1, extended_size2 = extended_size1 - i, extended_size2 - i
                                    lines_before_original_dynamic_context = lines_before_original[i:]
                                    lines_before_new_dynamic_context = lines_before_new[i:]
                                    if lines_before_original_dynamic_context == lines_before_new_dynamic_context:
                                        # get_logger().debug(f"found dynamic context match for section "
                                        #                   f"header: {section_header}")
                                        found_header = True
                                        section_header = ''
                                    else:
                                        # It's ok to be here. We can't apply dynamic context if the
                                        # lines are different in 'old' and 'new' hunks
                                        pass
                                    break

                            if not found_header:
                                # get_logger().debug(f"Section header not found in the extra lines before the hunk")
                                extended_start1, extended_size1, extended_start2, extended_size2 = \
                                    _calc_context_limits(patch_extra_lines_before)
                        else:
                            extended_start1, extended_size1, extended_start2, extended_size2 = \
                                _calc_context_limits(patch_extra_lines_before)

                        # check if extra lines before hunk are different in original and new file
                        delta_lines_original = [
                            f' {line}' for line in file_original_lines[extended_start1 - 1:start1 - 1]
                        ]
                        if file_new_lines:
                            delta_lines_new = [f' {line}' for line in file_new_lines[extended_start2 - 1:start2 - 1]]
                            if delta_lines_original != delta_lines_new:
                                found_mini_match = False
                                for i in range(len(delta_lines_original)):
                                    if delta_lines_original[i:] == delta_lines_new[i:]:
                                        delta_lines_original = delta_lines_original[i:]
                                        delta_lines_new = delta_lines_new[i:]
                                        extended_start1 += i
                                        extended_size1 -= i
                                        extended_start2 += i
                                        extended_size2 -= i
                                        found_mini_match = True
                                        break
                                if not found_mini_match:
                                    extended_start1 = start1
                                    extended_size1 = size1
                                    extended_start2 = start2
                                    extended_size2 = size2
                                    delta_lines_original = []
                                    # get_logger().debug(f"Extra lines before hunk are different",
                                    #                    artifact={"delta_lines_original": delta_lines_original,
                                    #                              "delta_lines_new": delta_lines_new})

                        # Remove section header if present in extra delta lines (also done for dynamic context)
                        if section_header and not allow_dynamic_context:
                            for line in delta_lines_original:
                                if section_header in line:
                                    section_header = ''  # remove section header if it is in the extra delta lines
                                    break
                    else:
                        extended_start1 = start1
                        extended_size1 = size1
                        extended_start2 = start2
                        extended_size2 = size2
                        delta_lines_original = []
                    # Keep the original header numbering for a hunk that is still zero-length after extension
                    if extended_size1 == 0:
                        extended_start1 = header_start1
                    if extended_size2 == 0:
                        extended_start2 = header_start2
                    extended_patch_lines.append('')
                    extended_patch_lines.append(
                        f'@@ -{extended_start1},{extended_size1} '
                        f'+{extended_start2},{extended_size2} @@ {section_header}')
                    extended_patch_lines.extend(delta_lines_original)  # one to zero based
                    last_extended_old_line = extended_start1 + extended_size1 - 1
                    continue
            extended_patch_lines.append(line)
    except Exception as e:
        get_logger().warning(f"Failed to extend patch: {e}", artifact={"traceback": traceback.format_exc()})
        return patch_str

    # finish processing last hunk
    if start1 != -1 and extra_lines_after > 0 and is_valid_hunk:
        delta_lines_original = file_original_lines[start1 + size1 - 1:start1 + size1 - 1 + extra_lines_after]
        # add space at the beginning of each extra line
        delta_lines_original = [f' {line}' for line in delta_lines_original]
        extended_patch_lines.extend(delta_lines_original)

    extended_patch_str = '\n'.join(extended_patch_lines)
    return extended_patch_str

def check_if_hunk_lines_matches_to_file(i, original_lines, patch_lines, start1):
    """
    Check if the hunk lines match the original file content. We saw cases where the hunk header
    line doesn't match the original file content, and then extending the hunk with extra lines
    before the hunk header can cause the hunk to be invalid.
    """
    is_valid_hunk = True
    try:
        if i + 1 < len(patch_lines) and patch_lines[i + 1][0] == ' ': # an existing line in the file
            if patch_lines[i + 1].strip() != original_lines[start1 - 1].strip():
                # check if different encoding is needed
                original_line = original_lines[start1 - 1].strip()
                for encoding in ['iso-8859-1', 'latin-1', 'ascii', 'utf-16']:
                    try:
                        if original_line.encode(encoding).decode().strip() == patch_lines[i + 1].strip():
                            get_logger().info(
                            f"Detected different encoding in hunk header line {start1}, needed encoding: {encoding}"
                        )
                            return False # we still want to avoid extending the hunk. But we don't want to log an error
                    except (UnicodeError, LookupError):
                        # this encoding cannot represent the line, so it is not a match.
                        # Fall through and try the next candidate encoding.
                        pass

                is_valid_hunk = False
                get_logger().info(
                    f"Invalid hunk in PR, line {start1} in hunk header doesn't match the original file content")
    except Exception as e:
        # the check itself failed (for example a hunk header pointing past the end of the
        # original file), so the hunk cannot be trusted. Report it as invalid rather than
        # silently leaving is_valid_hunk at its True default and extending a bogus hunk.
        is_valid_hunk = False
        get_logger().info(
            f"Could not validate hunk starting at line {start1} against the original file content",
            artifact={"error": str(e)})
    return is_valid_hunk


def extract_hunk_headers(match):
    res = list(match.groups())
    start1 = int(res[0]) if res[0] is not None else 0
    size1 = int(res[1]) if res[1] is not None else 1
    start2 = int(res[2]) if res[2] is not None else 0
    size2 = int(res[3]) if res[3] is not None else 1
    section_header = res[4] if res[4] is not None else ""
    return section_header, size1, size2, start1, start2


def omit_deletion_hunks(patch_lines) -> str:
    """
    Omit deletion hunks from the patch and return the modified patch.
    Args:
    - patch_lines: a list of strings representing the lines of the patch
    Returns:
    - A string representing the modified patch with deletion hunks omitted
    """

    temp_hunk = []
    added_patched = []
    add_hunk = False
    inside_hunk = False

    for line in patch_lines:
        if line.startswith('@@'):
            match = RE_HUNK_HEADER.match(line)
            if match:
                # finish previous hunk: keep it only if it had additions,
                # otherwise drop it entirely (a deletion-only hunk must not
                # leak into the next hunk's output)
                if inside_hunk:
                    if add_hunk:
                        added_patched.extend(temp_hunk)
                    temp_hunk = []
                    add_hunk = False
                temp_hunk.append(line)
                inside_hunk = True
        else:
            temp_hunk.append(line)
            if line:
                edit_type = line[0]
                if edit_type == '+':
                    add_hunk = True
    if inside_hunk and add_hunk:
        added_patched.extend(temp_hunk)

    return '\n'.join(added_patched)


def handle_patch_deletions(patch: str, original_file_content_str: str,
                           new_file_content_str: str, file_name: str, edit_type: EDIT_TYPE = EDIT_TYPE.UNKNOWN) -> str:
    """
    Handle entire file or deletion patches.

    This function takes a patch, original file content, new file content, and file name as input.
    It handles entire file or deletion patches and returns the modified patch with deletion hunks omitted.

    Args:
        patch (str): The patch to be handled.
        original_file_content_str (str): The original content of the file.
        new_file_content_str (str): The new content of the file.
        file_name (str): The name of the file.

    Returns:
        str: The modified patch with deletion hunks omitted.

    """
    if not new_file_content_str and (edit_type == EDIT_TYPE.DELETED or edit_type == EDIT_TYPE.UNKNOWN):
        # logic for handling deleted files - don't show patch, just show that the file was deleted
        if get_verbosity_level() > 0:
            get_logger().info(f"Processing file: {file_name}, minimizing deletion file")
        patch = None # file was deleted
    else:
        patch_lines = split_diff_lines(patch)
        patch_new = omit_deletion_hunks(patch_lines)
        if patch_new and patch != patch_new:
            if get_verbosity_level() > 0:
                get_logger().info(f"Processing file: {file_name}, hunks were deleted")
            patch = patch_new
    return patch


def decouple_and_convert_to_hunks_with_lines_numbers(patch: str, file) -> str:
    """
    Convert a given patch string into a string with line numbers for each hunk, indicating the new and old content of
    the file.

    Args:
        patch (str): The patch string to be converted.
        file: An object containing the filename of the file being patched.

    Returns:
        str: A string with line numbers for each hunk, indicating the new and old content of the file.

    example output:
## src/file.ts
__new hunk__
881        line1
882        line2
883        line3
887 +      line4
888 +      line5
889        line6
890        line7
...
__old hunk__
        line1
        line2
-       line3
-       line4
        line5
        line6
           ...
    """

    # Add a header for the file
    if file:
        # if the file was deleted, return a message indicating that the file was deleted
        if hasattr(file, 'edit_type') and file.edit_type == EDIT_TYPE.DELETED:
            return f"\n\n## File '{file.filename.strip()}' was deleted\n"

        patch_with_lines_str = f"\n\n## File: '{file.filename.strip()}'\n"
    else:
        patch_with_lines_str = ""

    rendered_hunks = []
    patch_lines = split_diff_lines(patch)
    new_content_lines = []
    old_content_lines = []
    match = None
    start1, size1, start2, size2 = -1, -1, -1, -1
    prev_header_line = []
    header_line = []
    skip_hunk = False
    for line_i, line in enumerate(patch_lines):
        if line == NO_NEWLINE_AT_EOF_MARKER:
            continue

        if line.startswith('@@'):
            hunk_header_match = RE_HUNK_HEADER.match(line)
            if not hunk_header_match:
                get_logger().warning("Skipping a line that starts with '@@' but is not a unified "
                                     "hunk header", artifact={"line": line})
                skip_hunk = True
                continue
            skip_hunk = False
            header_line = line
            match = hunk_header_match
            if match and (new_content_lines or old_content_lines):  # found a new hunk, split the previous lines
                if prev_header_line:
                    patch_with_lines_str += f'\n{prev_header_line}\n'
                is_plus_lines = is_minus_lines = False
                if new_content_lines:
                    is_plus_lines = any(line.startswith('+') for line in new_content_lines)
                if old_content_lines:
                    is_minus_lines = any(line.startswith('-') for line in old_content_lines)
                # Always present the new hunk for the section, otherwise the LLM gets confused
                if is_plus_lines or is_minus_lines:
                    patch_with_lines_str = patch_with_lines_str.rstrip('\r\n') + '\n__new hunk__\n'
                    for i, line_new in enumerate(new_content_lines):
                        patch_with_lines_str += f"{start2 + i} {line_new}\n"
                if is_minus_lines:
                    patch_with_lines_str = patch_with_lines_str.rstrip('\r\n') + '\n__old hunk__\n'
                    for line_old in old_content_lines:
                        patch_with_lines_str += f"{line_old}\n"
                # Keep completed hunks out of subsequent rstrip/concatenation work.
                rendered_hunks.append(patch_with_lines_str)
                patch_with_lines_str = ""
                new_content_lines = []
                old_content_lines = []
            if match:
                prev_header_line = header_line

            section_header, size1, size2, start1, start2 = extract_hunk_headers(match)

        elif skip_hunk:
            continue
        elif match is None:
            # Ignore unified-diff file metadata before the first valid hunk.
            continue
        elif line.startswith('+'):
            new_content_lines.append(line)
        elif line.startswith('-'):
            old_content_lines.append(line)
        else:
            if not line and line_i: # if this line is empty and the next line is a hunk header, skip it
                if line_i + 1 < len(patch_lines) and patch_lines[line_i + 1].startswith('@@'):
                    continue
                elif line_i + 1 == len(patch_lines):
                    continue
            new_content_lines.append(line)
            old_content_lines.append(line)

    # finishing last hunk
    if match and (new_content_lines or old_content_lines):
        patch_with_lines_str += f'\n{header_line}\n'
        is_plus_lines = is_minus_lines = False
        if new_content_lines:
            is_plus_lines = any(line.startswith('+') for line in new_content_lines)
        if old_content_lines:
            is_minus_lines = any(line.startswith('-') for line in old_content_lines)
        # Always present the new hunk for the section, otherwise the LLM gets confused
        if is_plus_lines or is_minus_lines:
            patch_with_lines_str = patch_with_lines_str.rstrip('\r\n') + '\n__new hunk__\n'
            for i, line_new in enumerate(new_content_lines):
                patch_with_lines_str += f"{start2 + i} {line_new}\n"
        if is_minus_lines:
            patch_with_lines_str = patch_with_lines_str.rstrip('\r\n') + '\n__old hunk__\n'
            for line_old in old_content_lines:
                patch_with_lines_str += f"{line_old}\n"

    rendered_hunks.append(patch_with_lines_str)
    return "".join(rendered_hunks).rstrip('\r\n')


def extract_hunk_lines_from_patch(patch: str, file_name, line_start, line_end, side,
                                  remove_trailing_chars: bool = True) -> tuple[str, str]:
    try:
        try:
            line_start = int(line_start)
        except (ValueError, TypeError):
            get_logger().warning(f"Ignoring invalid line_start {line_start!r} for '{file_name}'")
            line_start = -1
        try:
            line_end = int(line_end)
        except (ValueError, TypeError):
            get_logger().warning(f"Ignoring invalid line_end {line_end!r} for '{file_name}'")
            line_end = -1
        patch_with_lines_str = f"\n\n## File: '{file_name.strip()}'\n\n"
        selected_lines = ""
        patch_lines = split_diff_lines(patch)
        match = None
        start1, size1, start2, size2 = -1, -1, -1, -1
        skip_hunk = False
        selected_lines_num = 0
        for line in patch_lines:
            if line == NO_NEWLINE_AT_EOF_MARKER:
                continue

            if line.startswith('@@'):
                match = RE_HUNK_HEADER.match(line)
                if not match:
                    get_logger().warning("Skipping a line that starts with '@@' but is not a "
                                         "unified hunk header", artifact={"line": line})
                    skip_hunk = True
                    continue
                skip_hunk = False
                selected_lines_num = 0
                header_line = line

                section_header, size1, size2, start1, start2 = extract_hunk_headers(match)

                # keep every hunk that overlaps the requested line range, so a
                # range spanning multiple hunks is not silently truncated
                if side.lower() == 'left':
                    if not (size1 > 0 and line_end >= start1 and line_start <= start1 + size1 - 1):
                        skip_hunk = True
                        continue
                elif side.lower() == 'right':
                    if not (size2 > 0 and line_end >= start2 and line_start <= start2 + size2 - 1):
                        skip_hunk = True
                        continue
                patch_with_lines_str += f'\n{header_line}\n'

            elif not skip_hunk:
                side_lower = side.lower()
                if side_lower in ("left", "right"):
                    is_left = side_lower == "left"
                    hunk_start = start1 if is_left else start2
                    line_exists_on_side = not line.startswith("+" if is_left else "-")
                    in_range = line_start <= hunk_start + selected_lines_num <= line_end
                    if in_range and (line_exists_on_side or not is_left):
                        selected_lines += line + '\n'
                    if line_exists_on_side:
                        selected_lines_num += 1
                patch_with_lines_str += line + '\n'
    except Exception as e:
        get_logger().error(
            f"Failed to extract hunk lines from patch: {e}", artifact={"traceback": traceback.format_exc()}
        )
        return "", ""

    if remove_trailing_chars:
        patch_with_lines_str = patch_with_lines_str.rstrip('\r\n')
        selected_lines = selected_lines.rstrip('\r\n')

    return patch_with_lines_str, selected_lines
