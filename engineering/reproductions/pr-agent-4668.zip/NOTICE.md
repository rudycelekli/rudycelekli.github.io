# Source notices

The two PR-Agent snapshots retain their exact upstream MIT LICENSE files under `sources/baseline/LICENSE` and `sources/candidate/LICENSE`. The pinned unidiff wheel retains its embedded MIT LICENSE and AUTHORS files. These third-party notices must be preserved in redistributions. The runner is an isolated reproduction harness; it does not replace the upstream application or assert its complete behavior.
